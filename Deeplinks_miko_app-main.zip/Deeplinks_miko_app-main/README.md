# Deeplink Miko App

This repository contains a Maestro end-to-end test flow for Miko 3 app deep links.
The flow opens supported Branch links, verifies the destination screen, exits the
opened experience, and returns the app to the launcher.

## Prerequisites

- Miko 3 app installed with package ID `com.miko3.app`
- A physical device or emulator capable of running the app
- [Maestro](https://maestro.mobile.dev/) installed and available on the `PATH`
- Android device/emulator connected and recognized by ADB

## Run the flow

From the repository directory:

```powershell
maestro test deeplink.yaml
```

To target a specific connected device:

```powershell
maestro test --device <device-id> deeplink.yaml
```

## Tested deep links

The flow currently exercises links for:

- Math Port
- Da Vinci's Games
- Talents
- Lazy Robber
- iHeart Stories
- Oomee Crane
- City Dunk
- Out of This Word
- Dreamy Kid
- Miko Music

## Notes

- Start the app flow from the Android Home screen. The flow presses **Home**
  before each deep link.
- The Parents Zone links may show a passcode screen. The flow enters `1111`
  when that screen is displayed.
- Smart Music, Science or Magic, and Smart Games are marked optional because
  they may open the Kids Zone home screen instead of the game. This is an
  app-side issue; the flow attempts to return to the launcher and continues.
